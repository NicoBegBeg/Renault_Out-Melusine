class Task:

    def __init__(self,d_area,f_area,car_type,time):
        self.d_area=d_area
        self.f_area=f_area
        self.car_type=car_type
        self.time=time
